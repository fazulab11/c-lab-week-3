#include<iostream>
using namespace std;
int main()
{
	cout << "Hello World \nUniversity of Central Punjab \nFaculty of Information Technology \nOrientation Day 2026";
	cout << "\nWelcome\n2026\n45\n45 * 3\n1000 + 500 - 250\nTotal fee: 54000" << endl;
		return 0;
}
