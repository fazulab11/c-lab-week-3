
#include <iostream>
using namespace std;//mising using name space
	int main()
	{
		cout << "Orientation Day" << endl; //Missing semicolon
	    cout << "Total students: "<< 450 << endl; //Missing insertion operator
		cout << "Seats left: " << 500 - 450 << endl; 
		cout << "Have a nice day" << endl;
			//Incorrect quotation marks in the last
			return 0;
}